/*
   Package pkg is useful.
*/
package pkg
