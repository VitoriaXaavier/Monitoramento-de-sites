package pkg

import _ "github.com/golang/protobuf/proto" //@ diag(`Alas, it is deprecated.`)
