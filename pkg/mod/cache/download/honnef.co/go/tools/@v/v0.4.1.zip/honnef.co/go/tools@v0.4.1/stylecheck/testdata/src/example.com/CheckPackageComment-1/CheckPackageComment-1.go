package pkg //@ diag(`at least one file in a package should have a package comment`)
